--
-- Lua configuration script
-- read this script on program startup to specify initial
-- window location and dimensions
-- 
xpos = 100
ypos = 200
width = 800
height = 600
fullscreen = false
